package com.codingbox.core2_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Core21Application {

	public static void main(String[] args) {
		SpringApplication.run(Core21Application.class, args);
	}

}
