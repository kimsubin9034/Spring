package com.codingbox.core2_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Core21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
