package com.codingbox.springprjtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringprjtestApplicationTests {

	@Test
	void contextLoads() {
	}

}
