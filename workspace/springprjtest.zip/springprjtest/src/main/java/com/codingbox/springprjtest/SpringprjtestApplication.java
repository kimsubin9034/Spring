package com.codingbox.springprjtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringprjtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringprjtestApplication.class, args);
	}

}
