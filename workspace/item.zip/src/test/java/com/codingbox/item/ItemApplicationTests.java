package com.codingbox.item;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemApplicationTests {

	@Test
	void contextLoads() {
	}

}
