package com.codingbox.jpatest1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpatest1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
