package com.codingbox.jpatest1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpatest1Application {

	public static void main(String[] args) {
		SpringApplication.run(Jpatest1Application.class, args);
	}

}
