package com.testbox.testJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
