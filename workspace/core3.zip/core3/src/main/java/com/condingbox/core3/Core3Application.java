package com.condingbox.core3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Core3Application {

	public static void main(String[] args) {
		SpringApplication.run(Core3Application.class, args);
	}

}
