package com.codingbox.springprj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringprjApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringprjApplication.class, args);
	}

}
