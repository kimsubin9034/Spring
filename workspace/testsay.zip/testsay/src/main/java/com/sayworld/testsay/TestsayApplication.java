package com.sayworld.testsay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestsayApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestsayApplication.class, args);
	}

}
