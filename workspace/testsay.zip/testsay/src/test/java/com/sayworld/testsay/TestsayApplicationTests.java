package com.sayworld.testsay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestsayApplicationTests {

	@Test
	void contextLoads() {
	}

}
